require 'test/unit'
require './upg10'

class TestRegEx < Test::Unit::TestCase
  def test_get_username
    assert_equal('Brian', get_username('USERNAME: Brian'))
    assert_equal('Brian', get_username('USERNAME:     Brian'))
    assert_equal('Brian', get_username('RightAName:  Brian'))
    assert_equal('Brian', get_username('username: Brian'))
    assert_equal(nil, get_username('USERNAME  Brian'))
    assert_equal(nil, get_username('USERNAME:Brian'))
  end
end
