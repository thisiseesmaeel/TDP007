require './upg11'
require 'test/unit'

class Testupg11 < Test::Unit::TestCase
  def test_white_page
    assert_equal(['!DOCTYPE', 'HTML', 'HEAD', 'TITLE', 'BODY', 'a', 'img'],
                 tag_names('https://www.ledr.com/colours/white.htm'),
                 'wrong tags whitepage')
  end

  def test_google
    assert_equal(
      ['!doctype', 'html', 'head', 'meta', 'title', 'script', 'style', 'body',
       'div', 'nobr', 'b', 'a', 'u', 'span', 'center', 'br', 'img', 'form',
       'table', 'tr', 'td', 'input', 'p'],
      tag_names('http://www.google.com/'),
      'Wrong google tags'
    )
  end
end
