require 'open-uri'

def tag_names(website)
  html = open(website, &:read)
  arr = html.scan(%r{<[^>|/|\s|=]+}).map { |tag| tag[1..-1] }
  arr.uniq
end
