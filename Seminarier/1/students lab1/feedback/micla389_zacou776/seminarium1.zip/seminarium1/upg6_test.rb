require './upg6'
require 'test/unit'

class Testupg6 < Test::Unit::TestCase
  def test_age
    bob = Person.new(10)
    assert_equal(10, bob.age, 'wrong age')
    assert_equal(2011, bob.birthyear, 'wrong year')
    assert_equal('', bob.name.fullname, 'wrong name')
  end

  def test_age_and_first
    bob = Person.new(25, 'Bob')
    assert_equal(25, bob.age, 'wrong age')
    assert_equal(1996, bob.birthyear, 'wrong year')
    assert_equal('Bob', bob.name.fullname, 'wrong name')
  end

  def test_all_correct
    bob = Person.new(2000, 'Bob', 'Dyllan')
    assert_equal(2000, bob.age, 'wrong age')
    assert_equal(21, bob.birthyear, 'wrong year')
    assert_equal('Dyllan Bob', bob.name.fullname, 'wrong name')
  end
end
