require 'test/unit'
require './upg2'

class TestFaculty < Test::Unit::TestCase
  def test_factorial20
    assert_equal(2_432_902_008_176_640_000, factorial20)
  end

  def test_factorial
    assert_equal(2_432_902_008_176_640_000, factorial(20))
    assert_equal(1, factorial(0))
    assert_equal(factorial(20), factorial20)
    assert_equal(nil, factorial(-1))
  end
end
