def factorial20
  (1..20).inject(1) { |res, entry| res * entry }
end

def factorial(n)
  # Check if n is larger than -1, if true perform factorial operation else return nil.
  n > -1 ? (1..n).inject(1) { |res, entry| res * entry } : nil
end
