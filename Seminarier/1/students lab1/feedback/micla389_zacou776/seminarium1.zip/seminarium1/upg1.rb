def n_times(n, &block)
  (0...n).each do |_i|
    block.call
  end
end

class Repeat
  @repeats = 0
  def initialize(n)
    @repeats = n
  end

  def each(&block)
    n_times(@repeats, &block)
  end
end
