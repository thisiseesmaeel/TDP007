class PersonName
  attr_reader :name, :surname

  def initialize
    @name = ''
    @surname = ''
  end

  def fullname
    if @surname.nil? && @name.nil?
      ''
    elsif @surname.nil?
      name
    elsif @name.nil?
      surname
    else
      [surname, name].join(' ')
    end
  end

  def fullname=(name)
    name_array = name.split(' ')
    @name = name_array[1]
    @surname = name_array[0]
  end
end
