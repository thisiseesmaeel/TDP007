class Array
  def rotate_left(n = 1)
    (1..n).each do |_i|
      index = length - 1

      reverse.each do |element|
        temp = element

        if index.zero?
          self[length - 1] = temp
        else
          self[index - 1] = temp
        end

        index -= 1
      end
    end
  end
end
