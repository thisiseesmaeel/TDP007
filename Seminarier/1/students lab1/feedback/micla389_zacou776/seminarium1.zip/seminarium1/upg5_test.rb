require 'test/unit'
require './upg5'

class TestPersonName < Test::Unit::TestCase
  def test_init
    p_name = PersonName.new
    p_name.fullname = 'Cesar Julio'
    assert_equal('Julio', p_name.name)
    assert_equal('Cesar', p_name.surname)
  end

  def test_fullname
    p_name = PersonName.new
    p_name.fullname = 'Cesar Julio'
    assert_equal('Cesar Julio', p_name.fullname)
  end
end
