require 'test/unit'
require './upg9'

class TestRotatation < Test::Unit::TestCase
  def test_rotate_left
    test = [1, 2, 3]
    test.rotate_left
    assert_equal([2, 3, 1], test)
    # Same array as above
    test.rotate_left(3)
    assert_equal([2, 3, 1], test)

    test = [1]
    test.rotate_left(1)
    assert_equal([1], test)

    test = [1, 2, 3]
    test.rotate_left(0)
    assert_equal([1, 2, 3], test)

    test = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    test.rotate_left(9)
    assert_equal([10, 1, 2, 3, 4, 5, 6, 7, 8, 9], test)
  end
end
