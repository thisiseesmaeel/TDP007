def get_username(input)
  # Replace multiple spaces with singular.
  input.gsub!(/\s+/, ' ')

  start_index = /:\s[a-zA-Z]+/=~ input

  if !start_index
    puts('No username could be found in the correct format.')
  else
    # To get the first letter
    start_index += 2

    input[start_index..-1]
  end
end
