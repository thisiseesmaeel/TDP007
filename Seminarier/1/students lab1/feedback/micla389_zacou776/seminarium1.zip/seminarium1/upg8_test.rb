require './upg8'
require 'test/unit'

class Testupg8 < Test::Unit::TestCase
  def test_lol
    assert_equal('LOL', 'Laugh out loud'.acronym, 'Wrong acronym')
  end

  def test_bob
    assert_equal('BOR', 'Bring out rasberries'.acronym, 'Wrong acronym')
  end

  def test_a_lot
    assert_equal('CWNDTNTIRTMT', 'Can we not do this now this is realy too much text'.acronym, 'Wrong acronym')
  end

  def test_a_little
    assert_equal('', ''.acronym, 'Wrong acronym')
  end
end
