String.class_eval do
  def acronym
    putstring = split.map { |word| word[0] }.join
    putstring.upcase
  end
end
