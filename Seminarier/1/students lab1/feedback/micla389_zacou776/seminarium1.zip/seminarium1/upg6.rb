require 'date'
require './upg5'
class Person
  attr_reader :age, :birthyear
  attr_accessor :name

  def initialize(age = 0, first_name = '', surname = '')
    @age = age
    fix_year
    @name = PersonName.new
    @name.fullname = ("#{surname} #{first_name}")
  end

  def change_age(new_age)
    @age = new_age
    fix_year
  end

  def fix_year
    date = DateTime.now
    @birthyear = date.year - age
  end
end
