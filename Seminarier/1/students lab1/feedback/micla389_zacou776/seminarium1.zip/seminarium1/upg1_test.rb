require './upg1'
require 'test/unit'

class Testupg1 < Test::Unit::TestCase
  def test_n_times
    x = 0
    n_times(3) { x += 1 }
    assert_equal(3, x, 'in correct run int add block')
  end

  def test_n_times2
    strin = ''
    n_times(6) { strin += 'hello ' }
    assert_equal('hello hello hello hello hello hello ', strin, 'correct string add run')
  end

  def test_repeat
    x = 0
    re = Repeat.new(3)
    re.each { x += 1 }
    assert_equal(3, x, 'incorrect int add block form repeat.each')
  end
end
