#u5
class PersonName
  def initialize(n, sn)
    @name = n
    @surname = sn
  end

  def getFullName()
    return "#{@name} #{@surname}"
  end

  def setFullName(fullname)
    @name = fullname.split(" ")[0]
    @surname = fullname.split(" ")[1]
  end
end

#6
class Person
  def initialize(name, surname, age)
    @name = PersonName.new(name, surname)
    setAge(age)
  end

  def setAge(age)
    @age = age
    @birthyear = Time.now().year() - age
  end

  def setBirthyear(birthyear)
    @birthyear = birthyear
    @age = Time.now().year() - @birthyear
  end

  def getAge()
    return @age
  end

  def getBirthyear()
    return @birthyear
  end
end
