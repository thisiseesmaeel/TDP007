#u1
def n_times(n, &block)
  for i in 1..n
    block.call()
  end
end

class Repeat
  def initialize(n)
    @number = n
  end

  def each(&block)
    for i in 1..@number
      block.call()
    end
  end
end

# notes:
#... exklusiv .. inklusiv

#u2
def factorial(n)
  return n <= 1 ? 1 : (1..n).inject { |sum, number| sum * number }
end

#u3
def longest_string(list)
  return list.sort_by { |e| -e.length }[0]
end
