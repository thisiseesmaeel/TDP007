#7
class Integer
  def fib()
    return (self <= 1) ? self : (self - 1).fib() + (self - 2).fib()
  end
end

# 8
class String
  def acronym()
    return split(" ").map { |w| w[0] }.join().upcase()
  end
end
