require "./Uppgift1"
require "test/unit"

class TestU1 < Test::Unit::TestCase
  def test_one
    kalle = Person.new("Volvo", "58435", 2, "M", 32)
    assert_equal(kalle.evaluate_policy("policy.rb"), 15.66)
    stina = Person.new("Volvo", "58435", 2, "K", 32)
    assert_equal(stina.evaluate_policy("policy.rb"), 17.4)
  end

  def test_two
    kalle = Person.new("BMW", "58937", 3, "M", 25)
    assert_equal(kalle.evaluate_policy("policy.rb"), 22.5)
    karl = Person.new("BMW", "58937", 4, "M", 25)
    assert_equal(karl.evaluate_policy("policy.rb"), 23)
    stina = Person.new("BMW", "58937", 3, "K", 25)
    assert_equal(stina.evaluate_policy("policy.rb"), 22.5)
  end

  def test_three
    kalle = Person.new("Volvo", "57937", 3, "M", 25)
    assert_equal(kalle.evaluate_policy("policy.rb"), 13.5)
  end
end
