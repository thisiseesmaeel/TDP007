class Person
  def initialize(car, post, drive_age, gender, age)
    @info = { :car => car, :post => post, :drive_age => drive_age,
              :gender => gender, :age => age }
    @points = 0
  end

  def evaluate_policy(filename)
    instance_eval(File.read(filename))
    return @points
  end

  def rules(r1, r2, amount)
    if (eval(r1) and eval(r2))
      @points *= amount
    end
  end

  def method_missing(name, *args)
    if (args[0].class == Range and args[0].include? (@info[name.to_sym])) || (@info[name.to_sym] == args[0])
      @points += args[1]
    end
  end
end

kalle = Person.new("Volvo", "58435", 2, "M", 32)
puts kalle.evaluate_policy("policy.rb")
