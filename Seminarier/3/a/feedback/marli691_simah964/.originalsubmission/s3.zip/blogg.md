# Seminarie 3:


## Uppgift 1

I denna uppgiften började vi med att skapa klassen Person. Vi valde att lägga informationen om personen i en hashtabell för att kunna lätt match informationen med det från policy.rb filen. Vi lade även till en medlemsvariabel för antalet poängen. När vi skapade funktionen evaluate_policy använde vi instance_eval för att kolla igenom filen och köra varje rad som ruby kod. Vi använder method_missing för alla värden som behövdes plussas på och  funktionen rule som ska kör multiplikation. I rule funktionen använder vi eval för att köra parameter strängarna som ruby kod. 

Vi tyckte inte det fanns mycket tolkningsutrymme, det kändes som att det var ganska klart vad som skulle göras. Det finns dock många olika sätt att skriva policy filen på. Vi tyckte själva att det var svårt att försöka få den lätt att skriva för icke programmerare. Vi lyckades kanske inte på det bästa sättet när det kommer till det. När vi skulle göra rule funktionen gjorde vi det så att det i policy filen i stort sätt bara skriver ut  ruby i sträng format vilket kanske inte är det bästa.

Det var inte särskilt många eller stora problem som uppstod i denna uppgiften. Vi satt en stund för att få det att fungera om man skickar in en range. Vi kände att det var nödvändigt eftersom man annars skulle behöva skriva ut varje ålder var för sig vilket skulle ta onödig tid. Tillslut kollade vi först om typen var en Range för att sedan kolla om rangen innehöll det som stod i hashtabellen. Om det inte var en range gjorde vi bara en vanlig jämförelse. Vi började även med att skriva ut varje variabel för sig istället för att ha det i en hash vilket skulle kräva mycket mer kod för att lösa. Något som också var lite klurigt var att utforma språket så att det skulle vara lätt användbart för icke programmerare. 

Tekniken som vi använde i denna uppgiften har vi svårt att veta hur det kan vara användbar. Av det lilla vi använde av den var det inte så svårt men det finns andra eval funktioner som vi inte känner till eller vet hur man ska använda.



## Uppgift 2

Vi stötte på ganska många problem när vi gjorde uppgift 2.
Vi började med att kopiera koden för DiceRoller klassen, övriga programmet (Rule, Parser etc.) behövde inte modifieras. Vi tog sedan bort "diceroll"-funktionen samt alla delar relaterade till slumpgenerering. Då hade vi ett simpelt programmeringsspråk som enbart hanterade matematiska operationer. En token för regexet "\w+" skapades och "\d+" togs bort för att enbart hantera allt som textsträngar.
Vi bytte också ut de matematiska operationerna mot not, and och or.

Blocket som skickas till :term hanterar omvandling från string till bool.
För att lagra variabler används den globala variabeln $vars som är ett hash. Vi försökte först ha en vars som en medlemsvariabel men det gick inte att komma åt den i blocket då det kördes i ett annan context (kanske letade efter @vars i Rule-klassen?). 

Att använda hash för lagring av variabler som skapades var ganska lätt att implementera med undantag för att den behövde ligga i det globala scopet. Efter att vi frågat assistent om hjälp kunde vi flytta variabeln till det locala scopen för blocket som skickades in i Parser-konstruktorn.

Vi tolkade uppgiften som att det enbart var bools som skulle hanteras, inga andra variabeltyper. Detta baserades på att det inte fanns någon atom-rule som kollade efter match(Integer) i instruktionerna för uppgiften.
Det hade varit svårare att göra uppgiften om slide #25 från föreläsningen inte fanns att jämföra med, där kunde vi se mönster mellan hur uppgiftsbeskrivningen såg ut och but implementationen skulle gå till. Reglerna för :var och :text behövde vi lägga till för att få programmet att fungera.

På uppgift 2 gick det inte att google på så många av lösningarna när vi fastnade på problem eftersom mycket var specifikt till Parser och Rule-klassen som vi fick av skolan. Vi fick istället titta på deras kod och lista ut hur t.ex. block skickades mellan funktionerna.

En medveten skillnad på exemplet och vår implementation är att vi inte har parenteser som del av syntaxet för assign och logiska operationer. Främsta anledningen till detta var att underlätta testerna när vi skrev programmet.

## Reflektion:

Av det ny vi arbetat med denna veckan känner vi inte igen det överhuvudtaget. Det var helt nytt för oss och därför behövde vi sätt oss in i det. Det blev att vi kollade mycket på exempel uppgifterna från föreläsningarna. Vi behövde även fråga om hjälp på andra uppgiften för att kunna förstå vad det var som skulle göras och hur. 

I början av uppgift 2 gjorde vi misstaget att ändra för mycket av koden på en gång och sedan när det uppstod problem visste vi inte exakt vilken del som orsakat det. Vi började om med en kopia av DiceRoller-klassen och ändrade en rad åt gången för att se var problemet uppstod. På så vis upptäckte t.ex. vi att to_s() behövde göras på det token som använde “\w+”, innan trodde vi att den redan var en sträng.

En detalj som kan göra det svårare att arbeta med ruby är att det är valfritt med parenteser vid funktionsanrop. Det gör det svårare att sätta sig in i någon annans kod då man inte direkt ser om det handlar om en variabel eller en funktion.
