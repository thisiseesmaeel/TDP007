require "./rdparse"
require "test/unit"

class TestU1 < Test::Unit::TestCase
  def test_one
    d = DiceRoller2.new
    d.log(false)

    assert_equal(d.test("true"), true)
    assert_equal(d.test("false"), false)
    assert_equal(d.test("not false"), true)
    assert_equal(d.test("not true"), false)
    assert_equal(d.test("or true false"), true)
    assert_equal(d.test("or false false"), false)
    assert_equal(d.test("and true false"), false)
    assert_equal(d.test("and true true"), true)
  end

  def test_two
    d = DiceRoller2.new
    d.log(false)
    puts d.test("set g true")

    assert_equal(d.test("not g"), false)
    assert_equal(d.test("or g false"), true)
    assert_equal(d.test("and g false"), false)
    assert_equal(d.test("and g true"), true)
  end

  def test_three
    d = DiceRoller2.new
    d.log(false)
    puts d.test("set g true")
    puts d.test("set h false")

    assert_equal(d.test("not h"), true)
    assert_equal(d.test("or g h"), true)
    assert_equal(d.test("and g h"), false)
  end

  def test_four
    d = DiceRoller2.new
    d.log(false)
    puts d.test("set hej true")

    assert_equal(d.test("not hej"), false)
    assert_equal(d.test("or hej false"), true)
    assert_equal(d.test("and hej false"), false)
    assert_equal(d.test("and hej true"), true)
  end

  def test_five
    d = DiceRoller2.new
    d.log(false)
    assert_equal(d.test("not not true"), true)
    assert_equal(d.test("not or false true"), false)
    assert_equal(d.test("not and false true"), true)
    assert_equal(d.test("and true and false true"), false)
  end

  def test_six
    d = DiceRoller2.new
    d.log(false)
    puts d.test("set g true")
    puts d.test("set k g")
    puts d.test("set j not k")

    assert_equal(d.test("g"), true)
    assert_equal(d.test("k"), true)
    assert_equal(d.test("j"), false)
  end
end
