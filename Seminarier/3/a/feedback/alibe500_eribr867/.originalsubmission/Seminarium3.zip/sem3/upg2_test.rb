require_relative 'upg2'
require 'test/unit'

class Testupg2 < Test::Unit::TestCase
    def test_basic
        assert_equal(true, test_string("true"), "true isn't true")
        assert_equal(false, test_string("false"), "true isn't true")
    end

    def test_and
        assert_equal(false, test_string("(and true false)"), "and case")
        assert_equal(false, test_string("(and (and true false) (and true true))"), "and case")

    end

    def test_or
        assert_equal(true, test_string("(or true false)"), "or case")
        assert_equal(true, test_string("(or (or true false) (or true true))"), "and case")
    end

    def test_not
        assert_equal(false, test_string("(not true)"), "not case")
        assert_equal(false, test_string("(not (or(and true false) (or true false)))"), "and case")
    end
    
    def test_set
        test_string("(set x true)")
        assert_equal(true, test_string("x"), "assignment case")
        test_string("(set y false)")
        assert_equal(true, test_string("(set y x)"), "assignment case")
    end
end
