carBrand
BMW         5
Citroen     4
Fiat        3
Ford 	    4
Mercedes    5
Nissan      4
Opel	    4
Volvo 	    5

postCode
nr58937	    9
nr58726	    5
nr58647 	3
nr45058     2
nr00093     3

licenseAge
nr0to1      3
nr2to3      4
nr4to15     4.5
nr16to99    5

gender
F           1
M           1

personAge
nr18to20  	2.5
nr21to23  	3
nr24to26  	3.5
nr27to29  	4
nr30to39  	4.5
nr40to64  	5
nr65to70  	4
nr71to99  	3

rule
gender      "m"
licenseAge  "<3"
scoreFactor "0.9"

rule
carBrand    "volvo"
postCode    "58***"
scoreFactor "1.2"

rule
carBrand    "mercedes"
postCode    "***93"
personAge   ">49"
scoreFactor "10"