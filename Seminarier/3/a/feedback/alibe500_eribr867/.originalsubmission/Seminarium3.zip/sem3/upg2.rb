require_relative 'rdparse'

class EvalLogic
  def initialize
    @@variables = {}
    @logic_parser = Parser.new('Evaluate logic') do
      token(/\s+/)
      token(/[a-zA-Z:]+/) { |m| m }
      token(/[()]/) { |m| m }

      start :VALID do
        match(:ASSIGN)
        match(:EXPR)
      end

      rule :EXPR do
        match('(', 'or', :EXPR, :EXPR, ')') { |_, _, ex1, ex2, _| ex1 or ex2 }
        match('(', 'and', :EXPR, :EXPR, ')') { |_, _, ex1, ex2, _| ex1 and ex2 }
        match('(', 'not', :EXPR, ')') { |_, _, ex, _| not ex }
        match(:TERM)
      end

      rule :ASSIGN do
        match('(', 'set', :VAR, :EXPR, ')') { |_, _, v, ex, _| @@variables[v] = ex }
      end

      rule :TERM do
        match('true') { true }
        match('false') { false }
        match(:VAR) { |var| @@variables[var] }
      end

      rule :VAR do
        match(/^(?!(and|not|or|true|false|set)$).*/) { |name| name }
      end
    end
  end

  def exit(strin)
    ["end", "exit", "break", "leave"].include? strin.chomp!
  end

  def run
    print 'running logic: '
    logic = gets
    if exit(logic)
      puts "exiting...."
    else
      puts "=> #{@logic_parser.parse logic}"
      run
    end
  end

  #primarly for testing purpose
  def parse_string(string)
    @logic_parser.parse string
  end
end

#main for test file, using global variable
TESTER = EvalLogic.new
def test_string(string)
ret = TESTER.parse_string(string)
end

def main()
  x = EvalLogic.new.run
end

if __FILE__ == $0
  main
end