class Person
  def initialize(car_brand, post_code, license_age, gender, age)
    @car_brand = car_brand
    @post_code = post_code
    @license_age = license_age
    @gender = gender
    @age = age

    @tables = []
    #table headers equals catagories
    @catagories = []
  end

# Translates the syntax of numbers into actual INT values or ranges into several values
# and makes all characters in the keys lowercase
  def clean_tables
    @tables.each_with_index do |table, index|
      if table[1].keys[0].match(/\d/)
        temp_hash = {}
        remade_hash = false
        table[1].keys.each do |key|
          @tables[index][1][key[2..-1]] = @tables[index][1].delete key
          key = key[2..-1]
          next unless key.include? 'to'
          #For numbers on either side of "to" make an entry for every number
          n1, n2 = key.match(/(\d+)to(\d+)/).captures
          (n1.to_i..n2.to_i).each { |i| temp_hash[i] = table[1][key] }
          remade_hash = true
        end
        #If hash is remade replace old hash with the new one
        @tables[index][1] = temp_hash if remade_hash
      else
        #Downcase keys in current table
        @tables[index][1] = table[1].transform_keys(&:downcase)
      end
    end
  end

#Pop rules out of tables and put them in their own list
  def get_rules
    found_rules = []
    @tables.reverse_each do |table|
      if table[0] == 'rule'
        found_rules << table[1]
        @tables.delete table
      end
    end

    found_rules
  end

=begin
Tables contains a header that describes the table and keys with relevant data connected to points
    in the score. For each table write a header name with first letter as lowercase then put the key
    first in the row and the point values to the right separated by any number of whitespaces.
    Numbers must be proceeded by "nr" in keys and if you want a range put "to" in between the beginning
    and end of the range (inclusive ranges).
  
    Ex:
    ageTable
    nr20     5   -----> Age 20 equals 5 points.
    nr60to99 90  -----> Ages 60 to 99 equals 90 points.

  Rules compare a persons data in the categories of the tables to certain parameters. For each rule 
    write a header as "rule" and the table you wish to search as the first value on a row. The first
    value has to match one of the table headers from the tables in the file. Then separate it from the
    search data with whitespaces and put the values searched for in quotes(""). 

    No special characters indicate an equals(=) comparison. A left or right arrow(<>) indicates a
    larger than or smaller than comparison. If you want to match part of the key then replace
    characters that can be anything with a star(*) this replaces characters with any character but still
    requires the same amount of characters.

    On the last row of the rule write "scoreFactor" on the left and a multiplier to the total score of
    the person as a number in quotes. For the scoreFactor to be multiplied to the score it requires all
    conditions under a "rule" to be met

    Ex:
    rule
    carBrand    "volvo"  -----> A person must have a carbrand with volvo.
    postCode    "58***"  -----> A person must live within a postcode that starts with 58.
    licenseAge  "<3"     -----> A person have had license for less than 3 years.
    scoreFactor "1.2"    -----> If all above are true, then multiply scorefactor to total points.
=end
  def evaluate_policy(filename)

    instance_eval(File.read(filename))

    rules = get_rules

    clean_tables

    total_points = 0
    attrs = [@car_brand, @post_code, @license_age, @gender, @age]
    #Adds values from the persons info according to tables
    @tables.each_with_index do |table, index|
      i = nil
      element = attrs[index]
      element.downcase! if element.is_a? String
      if table[1].key? element
        i = index
      end
      if i != nil
        total_points += table[1][attrs[i]]
      end
    end

    #Multiples score accoring to all rules set
    rules.each do |conditions|
      conditions_met = true
      conditions.each do |key, value|
        if (key == 'scoreFactor') && conditions_met
          total_points *= value.to_f
          break
        end
        #special cases for rules
        symb = value.match(/([*<>]+)/)
        if symb
          symb = symb.captures[0]
          if symb == '<'
            value.gsub!(/([*<>]+)/, '')
            conditions_met = false if attrs[@catagories.find_index(key)] >= value.to_i
          elsif symb == '>'
            value.gsub!(/([*<>]+)/, '')
            conditions_met = false if attrs[@catagories.find_index(key)] <= value.to_i
          elsif symb.include? '*'
            value.gsub!('*', '.')
            comp = Regexp.new value
            conditions_met = false unless attrs[@catagories.find_index(key)].match?(comp)
          end
        #if no special case perform equals comparasion
        elsif key != 'scoreFactor'
          conditions_met = false unless attrs[@catagories.find_index(key)].to_s == value.to_s
        end
      end
    end

    #return
    total_points.round(2)
  end

  #Adds all stuff in policy to hashmap with left value as keys and right value as values
  #in respective catagoris from headers.
  def method_missing(name, *args)
    if args.length == 0
      @tables << [name.to_s, {}]
      @catagories << name.to_s
    else
      @tables[-1][1][name.to_s] = args[0]
    end
  end
end

def main
  kalle = Person.new('bmw', '58726', 2, 'm', 40)
  total_points = kalle.evaluate_policy('policy.rb')
  p total_points
end

if __FILE__ == $0
  main
end