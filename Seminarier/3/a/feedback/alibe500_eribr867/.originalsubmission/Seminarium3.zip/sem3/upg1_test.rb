require_relative 'upg1'
require 'test/unit'

class Testupg1 < Test::Unit::TestCase

    def test_example_person
        #rule nr 1 and rule nr 2 is true: 20 * 0.9 * 1.2 = 21.6
        kalle = Person.new("volvo", "58726", 2 , "m", 40)
        total_points = kalle.evaluate_policy("policy.rb")

        assert_equal(21.6, total_points)
    end

    def test_small
        #rule nr 1 is true: 17 * 0.9 = 15.6
        kalle = Person.new("volvo", "45058", 2 , "m", 40)
        total_points = kalle.evaluate_policy("policy.rb")
        assert_equal(15.3, total_points)
    end

    def test_outside_ranges
        kalle = Person.new("0", "0", 100 , "x", 0)
        total_points = kalle.evaluate_policy("policy.rb")
        assert_equal(0, total_points)
    end

    def test_first_row_every_table
        #can type in lowercase, it still applies.
        kalle = Person.new("bmw", "58937", 0 , "f", 18)
        total_points = kalle.evaluate_policy("policy.rb")
        assert_equal(20.5, total_points)
    end

    def test_new_rule
        #rule nr 3 is true: 18,5 * 10 = 185
        kalle = Person.new("mercedes", "00093", 5, "m", 50) 
        total_points = kalle.evaluate_policy("policy.rb")
        assert_equal(185, total_points)
    end
end
