# Reads a file and splits it into lines and returns in an array
def line_load(file)
  lines = File.readlines(file)
  lines.map! { |line| line.split(/\s+/) }
  # Drop header characters
  lines.map! { |line| line.drop(1) }
  # Match valid lines according to assignment
  lines.select! { |line| line[0].is_a? String and line[0].match(/\d+/) and line.length > 1 }
end

# Prints a table of teams ranked by goal differential
# and the closest team to a 0 differential
def handle_football(file)
  lines = line_load(file)
  # Match goals made and recieved for each team and put into respective lines
  lines.map! { |line| line << (line[6].to_i - line[8].to_i) }
  # Sort by closest to 0 differential
  lines.sort_by! { |line| line[-1].abs }
  puts "The team with closest goal differential to 0 is #{lines[0][1]}"
  # Sort by differential descending
  lines.sort_by! { |line| -line[-1] }
  # Print
  puts
  lines.each do |line|
    puts (line[1]).to_s.ljust(15) + ':'.ljust(2) +
         (line[-1]).to_s.rjust(4)
  end
  lines
end

# Prints a table of days ranked by temperature differential
# and the closest day to a 0 differential
def handle_weather(file)
  lines = line_load(file)
  # Convert temperatur string info into INT and puts differential last in line
  lines.map! do |line|
    line << (line[1].gsub(/[^0-9]/, '').to_i -
     line[2].gsub(/[^0-9]/, '').to_i)
  end
  # Sorty by  closest diff to 0
  lines.sort_by! { |line| line[-1].abs }
  puts "The least volitile weather is on day #{lines[0][0]} with #{lines[0][-1]} degrees difference"
  # Sorty by diff descending
  lines.sort_by! { |line| -line[-1] }
  # Print
  puts
  puts('Day'.ljust(4) + ':'.ljust(2) + 'Diff')
  lines.each do |line|
    puts (line[0]).to_s.ljust(4) + ':'.ljust(2) +
         (line[-1]).to_s.rjust(4)
  end
  lines
end
