require_relative 'upg2'
require 'test/unit'

class Testupg2 < Test::Unit::TestCase

  def test_event_html
    all_events = convert_and_print_file("event.html")  

    events_in_arr = Array.new
    for event in all_events
      events_in_arr << event.event_map
    end 

    assert_equal(all_events.length, 8)
    assert_equal(events_in_arr, 
      [{"Posted by"=>"silvermoon82",
      "Website"=>"http://www.cfrc.ca",
      "description"=>
      "\"The Dark Carnival is two hours of spooky goodness. Every week, expect the best goth, industrial, and other dark music, as well as news and reviews from the wider world of goth culture. Embrace the darkness! Fridays, from 10 PM until the Witching Hour.\"",
      "dtstart"=>"2008-01-04 10:00pm EST",
      "locality"=>"Kingston",
      "region"=>"Ontario",
      "summary"=>"The Dark Carnival - 101.9FM"},
    {"Cost"=>"Free",
      "Posted by"=>"LunaSlave",
      "description"=>"Gothic, Industrial, Dark Alternative w/ DJ LunaSlave",
      "dtstart"=>"2008-01-06",
      "locality"=>"Belleville",
      "region"=>"Ontario",
      "summary"=>"Sinister Sundays"},
    {"Posted by"=>"silvermoon82",
      "Website"=>"http://www.cfrc.ca",
      "description"=>
      "\"The Dark Carnival is two hours of spooky goodness. Every week, expect the best goth, industrial, and other dark music, as well as news and reviews from the wider world of goth culture. Embrace the darkness! Fridays, from 10 PM until the Witching Hour.\"",
      "dtstart"=>"2008-01-11 10:00pm EST",
      "locality"=>"Kingston",
      "region"=>"Ontario",
      "summary"=>"The Dark Carnival - 101.9FM"},
    {"Cost"=>"Free",
      "Posted by"=>"LunaSlave",
      "description"=>"Gothic, Industrial, Dark Alternative w/ DJ LunaSlave",
      "dtstart"=>"2008-01-13",
      "locality"=>"Belleville",
      "region"=>"Ontario",
      "summary"=>"Sinister Sundays"},
    {"Posted by"=>"silvermoon82",
      "Website"=>"http://www.cfrc.ca",
      "description"=>
      "\"The Dark Carnival is two hours of spooky goodness. Every week, expect the best goth, industrial, and other dark music, as well as news and reviews from the wider world of goth culture. Embrace the darkness! Fridays, from 10 PM until the Witching Hour.\"",
      "dtstart"=>"2008-01-18 10:00pm EST",
      "locality"=>"Kingston",
      "region"=>"Ontario",
      "summary"=>"The Dark Carnival - 101.9FM"},
    {"Cost"=>"Free",
      "Posted by"=>"LunaSlave",
      "description"=>"Gothic, Industrial, Dark Alternative w/ DJ LunaSlave",
      "dtstart"=>"2008-01-20",
      "locality"=>"Belleville",
      "region"=>"Ontario",
      "summary"=>"Sinister Sundays"},
    {"Posted by"=>"silvermoon82",
      "Website"=>"http://www.cfrc.ca",
      "description"=>
      "\"The Dark Carnival is two hours of spooky goodness. Every week, expect the best goth, industrial, and other dark music, as well as news and reviews from the wider world of goth culture. Embrace the darkness! Fridays, from 10 PM until the Witching Hour.\"",
      "dtstart"=>"2008-01-25 10:00pm EST",
      "locality"=>"Kingston",
      "region"=>"Ontario",
      "summary"=>"The Dark Carnival - 101.9FM"},
    {"Cost"=>"Free",
      "Posted by"=>"LunaSlave",
      "description"=>"Gothic, Industrial, Dark Alternative w/ DJ LunaSlave",
      "dtstart"=>"2008-01-27",
      "locality"=>"Belleville",
      "region"=>"Ontario",
      "summary"=>"Sinister Sundays"}])
  end

  def test_event2_html

    all_events = []
    
    all_events = convert_and_print_file("event2.html")

    events_in_arr = Array.new

    for event in all_events
      events_in_arr << event.event_map
    end 

    assert_equal(all_events.length, 8)

    assert_equal(events_in_arr, 
      [{"Posted by"=>"silvermoon82",
      "Website"=>"http://www.cfrc.ca",
      "description"=>
      "\"The Dark Carnival is two hours of spooky goodness. Every week, expect the best goth, industrial, and other dark music, as well as news and reviews from the wider world of goth culture. Embrace the darkness! Fridays, from 10 PM until the Witching Hour.\"",
      "dtstart"=>"2008-01-04 10:00pm EST",
      "locality"=>"Kingston",
      "region"=>"Ontario",
      "summary"=>"The Dark Carnival - 101.9FM"},
    {"Cost"=>"Free",
      "Posted by"=>"LunaSlave",
      "description"=>"Gothic, Industrial, Dark Alternative w/ DJ LunaSlave",
      "dtstart"=>"2008-01-06",
      "locality"=>"Belleville",
      "region"=>"Ontario",
      "summary"=>"Sinister Sundays"},
    {"Posted by"=>"silvermoon82",
      "Website"=>"http://www.cfrc.ca",
      "description"=>
      "\"The Dark Carnival is two hours of spooky goodness. Every week, expect the best goth, industrial, and other dark music, as well as news and reviews from the wider world of goth culture. Embrace the darkness! Fridays, from 10 PM until the Witching Hour.\"",
      "dtstart"=>"2008-01-11 10:00pm EST",
      "locality"=>"Kingston",
      "region"=>"Ontario",
      "summary"=>"The Dark Carnival - 101.9FM"},
    {"Cost"=>"Free",
      "Posted by"=>"LunaSlave",
      "description"=>"Gothic, Industrial, Dark Alternative w/ DJ LunaSlave",
      "dtstart"=>"2008-01-13",
      "locality"=>"Belleville",
      "region"=>"Ontario",
      "summary"=>"Sinister Sundays"},
    {"Posted by"=>"silvermoon82",
      "Website"=>"http://www.cfrc.ca",
      "description"=>
      "\"The Dark Carnival is two hours of spooky goodness. Every week, expect the best goth, industrial, and other dark music, as well as news and reviews from the wider world of goth culture. Embrace the darkness! Fridays, from 10 PM until the Witching Hour.\"",
      "dtstart"=>"2008-01-18 10:00pm EST",
      "locality"=>"Kingston",
      "region"=>"Ontario",
      "summary"=>"The Dark Carnival - 101.9FM"},
    {"Cost"=>"Free",
      "Posted by"=>"LunaSlave",
      "description"=>"Gothic, Industrial, Dark Alternative w/ DJ LunaSlave",
      "dtstart"=>"2008-01-20",
      "locality"=>"Belleville",
      "region"=>"Ontario",
      "summary"=>"Sinister Sundays"},
    {"Posted by"=>"silvermoon82",
      "Website"=>"http://www.cfrc.ca",
      "description"=>
      "\"The Dark Carnival is two hours of spooky goodness. Every week, expect the best goth, industrial, and other dark music, as well as news and reviews from the wider world of goth culture. Embrace the darkness! Fridays, from 10 PM until the Witching Hour.\"",
      "dtstart"=>"2008-01-25 10:00pm EST",
      "locality"=>"Kingston",
      "region"=>"Ontario",
      "summary"=>"The Dark Carnival - 101.9FM"},
    {"Cost"=>"Free",
      "Posted by"=>"LunaSlave",
      "description"=>"Gothic, Industrial, Dark Alternative w/ DJ LunaSlave",
      "dtstart"=>"2008-01-27",
      "locality"=>"Belleville",
      "region"=>"Ontario",
      "summary"=>"Sinister Sundays"}])
  end

  # Extracted vevent from event.html and put in two new example events in wall of text.  
  def test_wall_of_text
    all_events = []
    
    all_events = convert_and_print_file("event_example.html")

    assert_equal(all_events.length, 2)

    assert_equal(all_events[0].event_map["region"], "Östergötland")
    assert_equal(all_events[0].event_map["locality"], "Linköping")
    assert_equal(all_events[0].event_map["summary"], "Computer Science Class 101")
    assert_equal(all_events[0].event_map["dtstart"], "2021-01-06 3:00pm CET")
    assert_equal(all_events[0].event_map["description"], '"' + "Lecture about the basics of computer science." + '"')
    assert_equal(all_events[0].event_map["Posted by"], "Teacher")
    assert_equal(all_events[0].event_map["Website"], "http://www.liu.se/ida")

    assert_equal(all_events[1].event_map["region"], "Närke")
    assert_equal(all_events[1].event_map["locality"], "Örebro")
    assert_equal(all_events[1].event_map["summary"], "Math class 101")
    assert_equal(all_events[1].event_map["dtstart"], "2021-02-12 1:00pm CET")
    assert_equal(all_events[1].event_map["description"], '"' + "Basics of linear algebra." + '"')
    assert_equal(all_events[1].event_map["Posted by"], "Teacher2")
    assert_equal(all_events[1].event_map["Website"], "http://www.liu.se/mai")
  end

  #All tags will have empty strings in the text part
  def test_empty_text
    all_events = []
    
    all_events = convert_and_print_file("event_example_empty_text.html")

    assert_equal(all_events.length, 1)

    assert_equal(all_events[0].event_map["region"], "")
    assert_equal(all_events[0].event_map["locality"], "")
    assert_equal(all_events[0].event_map["summary"], "")
    assert_equal(all_events[0].event_map["dtstart"], "")
    assert_equal(all_events[0].event_map["description"], "")
    assert_equal(all_events[0].event_map["Posted by"], "")
    assert_equal(all_events[0].event_map["Website"], "")

  end

  def test_no_vevent_class
    all_events = []
    
    all_events = convert_and_print_file("event_test_no_event.html")

    #HTML contain no vevent class attribute
    assert_equal(all_events.length, 0)
  end
  
  #No class attribute with value label
  def test_no_label
    all_events = []
    
    all_events = convert_and_print_file("event_test_no_label.html")

    assert_equal(all_events.length, 1)
    # Values for keys that have expected value nil are not part of hashmap
    assert_equal(all_events[0].event_map["region"], "Närke")
    assert_equal(all_events[0].event_map["locality"], "Örebro")
    assert_equal(all_events[0].event_map["summary"], "Math class 101")
    assert_equal(all_events[0].event_map["dtstart"], "2021-02-12 1:00pm CET")
    assert_equal(all_events[0].event_map["description"], nil)
    assert_equal(all_events[0].event_map["Posted by"], nil)
    assert_equal(all_events[0].event_map["Website"], nil)
  end
end
