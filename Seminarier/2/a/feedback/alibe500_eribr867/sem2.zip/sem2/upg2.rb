require 'rexml/streamlistener'
require 'rexml/document'

# Defines a calendar event with an array of properties and functionalitry to add/change properties
class CalEvent
  attr_accessor :event_map

  def initialize
    @event_map = {}
  end
end

# Sax parser complient with REXML as a Streamlistener
class Reader
  include REXML::StreamListener

  attr_accessor :all_events, :rel_att

  # Add valid and relevant tags for a calendar event and intiialize variables
  def initialize
    @in_event = false
    @rel_att = { 'summary' => false, 'dtstart' => false, 'locality' => false,
                 'region' => false }
    @rel_label = ['Website:', 'Posted by:', 'Cost:']
    @all_events = []
    @label_key = ''
    @capture_text = ''
    @tag_depth = 0
    @label_state = 0
  end

  # Switches booleans to true when mathcing class is found
  # and intializes new calendar events on vevent class
  def tag_start(_name, attrs)
    @tag_depth += 1 if @in_event
    if attrs['class'] == 'vevent'
      @all_events << CalEvent.new
      @in_event = true
    end
    # Sets relevant variables when matching class is found
    unless attrs.nil?
      # Exception for label that have relevant info in text and not in attributes
      if attrs['class'] == 'label'
        @label_state = 2
      elsif @rel_att.has_key?(attrs['class'])
        @rel_att[attrs['class']] = true
      end
    end
  end

  # Puts found info into CalEvent s
  # and stops capturing info when end of event is found
  def tag_end(name)
    if @in_event
      if @tag_depth == 0
        @in_event = false
        return
      else
        @tag_depth -= 1
      end
      # Special case for p tags since the only valid p tag in a vevent is descripton text
      @all_events[-1].event_map['description'] = @capture_text if name == 'p'

      # Label handling that captures text instead of using class as hashmap keys
      if @label_state > 1
        if @rel_label.include? @capture_text
          @label_key = @capture_text[0..-2]
          @label_state -= 1
        end
      elsif @label_state > 0
        @all_events[-1].event_map[@label_key] = @capture_text
        @label_state -= 1
      end
      # Inserts new info about a CalEvent when mathcing class is ended
      @rel_att.each do |tag, bool|
        next unless bool

        @all_events[-1].event_map[tag] = @capture_text
        rel_att[tag] = false
      end
    end
  end

  def text(text)
    if @in_event
      #default string value when strings only contain non word/digit characters 
      if text.match?(/^\W+$/)
        @capture_text = ""
      else
        @capture_text = text
      end
    end
  end

  # Prints an event with info
  def print_all
    puts "----Calender Events---\n\n"
    @all_events.each do |event|
      event.event_map.each do |type, desc|
        puts "#{type.capitalize}: #{desc}\n"
      end
      puts
    end
  end
end


def convert_and_print_file(filename)
  rea = Reader.new
  src = File.new(filename)
  REXML::Document.parse_stream(src, rea)
  
  rea.print_all
  rea.all_events
end 

