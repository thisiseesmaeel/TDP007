## Seminarie 2:Strukturerad text, reguljära uttryck och XML


### Uppgift 1

I denna uppgiften började vi med att skapa en klass för att representera laget. Klassen innehåller med medlems variablerna som motsvarar namnet på laget, antal mål mot samt antal mål gjorda. För att sedan läsa in informationen från filen använde vi each för då kunde vi ta varje rad för sig. Vi vill endast att den ska fokusera på informationen som fanns mellan “pre” start- och sluttaggen. Därför började vi med att leta efter taggarna med include? funktionen, om starttaggen hittas sätter vi is_in_block variabeln till true och sluttaggen hittas blir variabeln false. I både av fallen går man också vidare till nästa rad. is_in_block har innan checken satt till false eftersom endast då starttaggen är hittad vill vi börja med att föra in information i objektet. Vi kollar även om raden innehåller en siffra med en punk efter sig eftersom alla lagen har de framför sig. Programmet hade fungerat med endast den sista checken, men vi tänkte att det i andra fall kan finnas mer information utanför taggarna som inte är intressant för oss.

När vi nått fram till rad med information så vi vill komma åt kan vi göra den raden till en array. Programmet skulle fungera med tabeller som såg ut på samma sätt, vi tänkte därför att det fungerar att räkna ut på vilke index i listan som de viktade värdena finns på. De värdena sätts in i ett objekt som efter det sätts in i en lista. Listan returneras. 

Funktionen sort_by_goal_diff använder sig av sort_by funktionen för att få rätt ordning på objekten. För att få det lag med minst skillnaden först tog vi skillnaden och gjorde det negativt.

Vi behövde inte ändra mycket i den andra deluppgiften. Det som vi ändrade var namnen, indexen som informationen fanns på. I sorteringen är den enda skillnaden att den är sorterat tvärtom. Denna skillnaden görs med ett minustecken. Det reguljära uttrycket för att kolla de viktiga raderna inför taggarna ändrades lite. I weather kollade vi bara om det som var på första indexet var en siffra.   

Värt att nämna var att vi började med en lösning som krävde att vi lagrade index i textsträngen där Team, F och A fanns och använde de för inläsning i kombination med ett regex som läste in fram till närmaste mellanslag. Denna lösning fungerade men var ganska omständig att återanvända på del 2 eftersom siffrorna denna gång blev höger-centrerade.
Vi fick programmet att fungera med den lösningen men bytte sedan ut det mot att använda split() på varje rad i textfilen och läsa in rätt index.


### Uppgift 2
I den här uppgiften började vi med att kopiera Team-klassen från tidigare uppgift och gjorde om den till en “Event”-klass.
Vi använde Nokogiri som parser då det kändes som att den hade bäst dokumentation. 
För att läsa in rätt data från HTML dokumentet kunde vi utgå från “Getting Started” exemplet som fanns på Nokogiris hemsida och anpassa tag och klass-namn till det vi letade efter.
För att extrahera innehållet från elementen används “.content”, den extraherade datan sparas sedan i variabler som skickades till Event-konstruktorn.
När vi fått allt att fungera flyttades inläsnings-funktionaliteten till en egen funktion som tog in en URL-parameter för att kunna läsa in alla kalendrar (med rätt format).

Länkarna och tipsen som fanns på kurshemsidan underlättade väldigt mycket eftersom vi t.ex. inte behövde leta genom hela html-filen efter vilka klass-namn som var relevanta då de var givna i dokumentationen för hCalendar..

### Reflektion

Generellt känns det väldigt smidigt att använda Ruby, det går snabbt att skapa klasser och man stöter sällan på syntax-problem. De flesta funktioner som finns inbyggda till t.ex. textsträngar och listor är väldigt lika de som fanns i Python vilket gjorde Ruby lätt att komma igång med. Inga av de syntax-relaterade problemen har tagit lång tid att lösa då det nästan alltid löser sig med en googling.
På första labben gjorde vi get-funktioner på samma sätt som i c++ men efter att ha tittat på lösningar från andra grupper bytte vi ut dessa mot attr_reader då det sparade mycket tid och kodrader. Det lämpade sig väldigt bra att använda attr_reader eftersom Team, Day och Event-klasserna endast fungerade som behållare för data med undantag för get_diff-funktionen i Day och Team-klassen.

Rubys inbyggda funktioner för omvandling från t.ex strängar till heltal är något som vi haft stor användning av. I uppgift 1 del 2 hanterade to_i() automatiskt strängar som t.ex. “12*” och översatte till heltalet 12 utan att vi behövde hantera det specialfallet.
