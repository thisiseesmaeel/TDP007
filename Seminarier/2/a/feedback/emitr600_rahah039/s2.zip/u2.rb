require "nokogiri"
require "open-uri"

class Event
  attr_reader :summary, :dtstart, :locality, :region

  def initialize(summary, dtstart, locality, region)
    @summary = summary
    @dtstart = dtstart
    @locality = locality
    @region = region
  end

  def get_info()
    return summary + "\n" + dtstart + "\n" + locality + "\n" + region
  end
end

def get_events(url)
  doc = Nokogiri::HTML(URI.open(url))
  events = []
  doc.css("div.vevent").each do |section|
    summary = section.css("span.summary")[0].content
    dtstart = section.css("span.dtstart")[0].content
    locality = section.css("span.locality")[0].content
    region = section.css("span.region")[0].content

    events.push(Event.new(summary, dtstart, locality, region))
  end
  return events
end

events = get_events("https://www.ida.liu.se/~TDP007/current/material/seminarie2/events.html")

#test
# events.each { |e| print e.get_info() }
