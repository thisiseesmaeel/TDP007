require "./football.rb"
require "./weather.rb"
require "./u2.rb"

require "test/unit"

require "date"

#u1
class TestU1D1 < Test::Unit::TestCase
  def test_one
    teams = get_teams("football.txt")
    teams = sort_by_goal_diff(teams)

    assert_equal("Arsenal", get_best_goal_diff_team(teams).name())
    assert_equal(["Arsenal", "Manchester_U", "Liverpool", "Chelsea", "Newcastle", "Leeds", "Blackburn", "Aston_Villa", "Tottenham", "Southampton", "Fulham", "West_Ham", "Charlton", "Middlesbrough", "Everton", "Bolton", "Sunderland", "Ipswich", "Derby", "Leicester"], teams.map { |e| e.name })
  end

  def test_two
    teams = get_teams("testfiles/football2.txt")
    teams = sort_by_goal_diff(teams)

    assert_equal("Arsenal", get_best_goal_diff_team(teams).name())
    assert_equal(["Arsenal", "Liverpool", "Ipswich"], teams.map { |e| e.name })
  end

  def test_three
    teams = get_teams("testfiles/football3.txt")
    teams = sort_by_goal_diff(teams)

    assert_equal(nil, get_best_goal_diff_team(teams))
    assert_equal([], teams)
  end
end

class TestU1D2 < Test::Unit::TestCase
  def test_one
    days = get_days("weather.txt")
    days = sort_by_temp_diff(days)

    assert_equal(14, get_lowest_temp_diff_day(days).day())
    assert_equal([14, 15, 13, 24, 12, 2, 7, 28, 4, 25, 27, 6, 10, 16, 19, 8, 3, 23, 29, 5, 17, 22, 20, 21, 1, 18, 11, 26, 30, 9], days.map { |e| e.day() })
  end

  def test_two
    days = get_days("testfiles/weather2.txt")
    days = sort_by_temp_diff(days)

    assert_equal(14, get_lowest_temp_diff_day(days).day())
    assert_equal([14, 15, 13], days.map { |e| e.day() })
  end

  def test_three
    days = get_teams("testfiles/weather3.txt")
    days = sort_by_temp_diff(days)

    assert_equal(nil, get_lowest_temp_diff_day(days))
    assert_equal([], days)
  end
end

#u2
class TestU2 < Test::Unit::TestCase
  def test_one
    events = get_events("https://www.ida.liu.se/~TDP007/current/material/seminarie2/events.html")
    events = events.map { |e| e.dtstart() }
    assert_equal(["2008-01-04 10:00pm EST", "2008-01-06", "2008-01-11 10:00pm EST", "2008-01-13", "2008-01-18 10:00pm EST", "2008-01-20", "2008-01-25 10:00pm EST", "2008-01-27"], events)
  end

  def test_two
    events = get_events("https://www.google.com")
    assert_equal([], events)
  end
end
