class Team
  attr_reader :name, :goals_for, :goals_against

  def initialize(n, f, a)
    @name = n
    @goals_for = f
    @goals_against = a
  end

  def get_diff
    return @goals_for - @goals_against
  end
end

def get_teams(filepath)
  teams = []

  is_in_block = false

  lines = File.open(filepath)
  lines.each do |line|
    #skip if outside block
    if (line.include? "<pre>")
      is_in_block = true
      next
    end
    if (line.include? "</pre>")
      is_in_block = false
      next
    end
    if (!is_in_block)
      next
    end

    elements = line.split()

    # skip if line doesn't start with number and a dot
    if (elements[0] =~ (/\d\./) ? false : true)
      next
    end

    name = elements[1]
    goals_for = elements[6].to_i()
    goals_against = elements[8].to_i()

    team = Team.new(name, goals_for, goals_against)
    teams.push(team)
  end
  return teams
end

def sort_by_goal_diff(teams)
  return teams.sort_by { |e| -e.get_diff() }
end

def get_best_goal_diff_team(teams)
  teams = sort_by_goal_diff(teams)
  return teams[0]
end

teams = get_teams("football.txt")
teams = sort_by_goal_diff(teams)

# test
# puts "Best diff: " + teams[0].name()
# puts "\nOrdered list:\n------\n"
# teams.each { |e| puts e.name() }
