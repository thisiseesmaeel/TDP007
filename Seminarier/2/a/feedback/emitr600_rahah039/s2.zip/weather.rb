class Day
  attr_reader :day, :mx, :mn

  def initialize(d, mx, mn)
    @day = d
    @mx = mx
    @mn = mn
  end

  def get_diff
    return @mx - @mn
  end
end

def get_days(filepath)
  days = []

  is_in_block = false

  lines = File.open(filepath)
  lines.each do |line|
    #skip if outside block
    if (line.include? "<pre>")
      is_in_block = true
      next
    end
    if (line.include? "</pre>")
      is_in_block = false
      next
    end
    if (!is_in_block)
      next
    end

    elements = line.split()

    # skip if line doesn't start with number
    if (elements[0] =~ (/\d/) ? false : true)
      next
    end

    day_number = elements[0].to_i()
    mx = elements[1].to_i()
    mn = elements[2].to_i()

    day = Day.new(day_number, mx, mn)
    days.push(day)
  end
  return days
end

def sort_by_temp_diff(days)
  return days.sort_by { |e| e.get_diff() }
end

def get_lowest_temp_diff_day(days)
  days = sort_by_temp_diff(days)
  return days[0]
end

#test:
# days = get_days("weather.txt")
# days = sort_by_temp_diff(days)

# puts "Best diff: " + days[0].day().to_s()
# puts "\nOrdered list:\n------\n"
# days.each { |e| puts e.day().to_s + " " + e.get_diff().to_s() }
