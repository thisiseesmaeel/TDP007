
# read table from file
def read_table(filename)
	file = File.open(filename)
	file.read =~ /<pre>\n(.*)<\/pre>/m
	return $1
end

# returns line with lowest goal difference from a table
def least_goal_diff(table)
	lowest_line = ""
	lowest_diff = -1

	table.each_line do |line|
		if line.include? '.'  # skip filler lines
			arr = line.split
			diff = (arr[6].to_i - arr[8].to_i).abs
			if lowest_diff == -1 or diff < lowest_diff
				lowest_line = line
				lowest_diff = diff
			end 
		end
	end
	return lowest_line
end

# returns new table ordered by goal difference
def rank_by_goal_diff(table)
	arr = table.split("\n")

	# create new table with column names
	new_table = table.slice!(arr[0] + "\n")

	# remove non-data lines from input table
	table.slice!(arr[-4] + "\n")

	# fill new table in order of goal difference
	index = 1
	while !table.empty?
		least = least_goal_diff(table)
		table.slice!(least)
		least =~ /\. (.+)\n/ 
		new_table += "#{index}. ".rjust(7) + $1 + "\n"
		index += 1

		# add line of '-' above the bottom 3 teams
		if table.split("\n").length == 3
			new_table += arr[-4] + "\n"
		end
	end
	return new_table
end


# returns line with lowest temperature difference from a table
def least_temp_diff(table)
	lowest_line = ""
	lowest_diff = -1

	table.each_line do |line|
		if line.match(/^ +\d+/) != nil # skip filler lines
			arr = line.split
			diff = (arr[1].to_i - arr[2].to_i).abs
			if lowest_diff == -1 or diff < lowest_diff
				lowest_line = line
				lowest_diff = diff
			end 
		end
	end
	return lowest_line
end

# returns new table ordered by temperature difference
def rank_by_temp_diff(table)
	arr = table.split("\n")

	# create new table with column names
	new_table = table.slice!(arr[2] + "\n")

	# remove non-data lines from input table
	table.slice!(arr[0] + "\n")
	table.slice!(arr[1] + "\n")
	table.slice!(arr[3] + "\n")
	table.slice!(arr[-1] + "\n")

	# fill new table in order of temperature difference
	index = 1
	while !table.empty?
		least = least_temp_diff(table)
		table.slice!(least)
		new_table += least
		index += 1
	end
	# add month summary line to new table
	new_table += arr[-1]
end
