require "rexml/document"
require "rexml/streamlistener"


class Event

	attr_reader :data
	attr_accessor :data

	def initialize
		@data = Hash.new()
	end

	def print
		puts "Event: " + @data["summary"]
		puts "Date: " + @data["dtstart"]


		if @data["org fn"]
			puts "Organization: " + @data["org fn"]
		end

		if @data["street-address"]
			puts "Street Address: " + @data["street-address"]
		end

		if @data["locality"]
			puts "City: " + @data["locality"]
		end

		if @data["region"]
			puts "State: " + @data["region"]
		end


		if @data["description"]
			puts "Description: " + @data["description"]
		end
	end
end

# Stream parsing
class MyListener
	include REXML::StreamListener

	def initialize(event_array)
		@event_array = event_array
		# keeps track of how many div tags we are inside 
		@div_depth = 0   
	end

	def tag_start(name, attrs)
		# if inside a div tag with the class vevent
		if @vevent
			if name == "div"
				@div_depth += 1
			end

			if attrs["class"] 
				# save the class value of the closest start tag
				@current_class = attrs["class"]
			end

		elsif name == "div"
			# create new event when a div tag with the vevent class is encountered
			if attrs["class"] == "vevent"
				@event = Event.new
				@event_array.append(@event)
				@vevent = true
				@div_depth = 1
			end
		end
	end

	def tag_end(name)
		if name == "div" and @vevent 
			if @div_depth == 1
				# reached end of div tag with the vevent class
				@vevent = false
			else
				# reached end of a nested div tag
				@div_depth -= 1
			end
		end
	end

	def text(text)
		if @vevent and text =~ /\w+/
			# save text data from tags with certain classes
			if @current_class == "summary" or @current_class == "dtstart" \
				or @current_class == "org fn" or @current_class == "street-address" \
				or @current_class == "locality" or @current_class == "region" \
				or @current_class == "description"
				@event.data[@current_class] = text
				@current_class = nil
			end
			
		end
	end
end



# DOM parsing
def dom_parsing(event_array, rexml_doc)
	rexml_doc.elements.each("//div[@class = 'vevent']") do |vevent|
		event = Event.new
		event_array.append(event)

		event.data['summary'] = vevent.get_elements(".//*[@class = 'summary']")[0].text
		event.data['dtstart'] = vevent.get_elements(".//*[@class = 'dtstart']")[0].text

		labels = ["org fn", "street-address", "locality", "region", "description"] 

		labels.each do |label|
			if label == "description"
				elements = vevent.get_elements(".//*[@class = '#{label}']/p")
			else
				elements = vevent.get_elements(".//*[@class = '#{label}']")
			end
			event.data[label] = elements[0].text if !elements.empty?
		end
	end
end


