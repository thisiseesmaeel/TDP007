

require 'test/unit'
require './sem2_upg1.rb'
require './sem2_upg2.rb'


class Tests_Upg1 < Test::Unit::TestCase
	def test_least_goal_diff
		table = read_table("football.txt")
		least_diff_line = "    8. Aston_Villa     38    12  14  12    46  -  47    50\n"

		assert_equal(least_goal_diff(table), least_diff_line)
	end

	def test_rank_by_goal_diff
		table = read_table("football.txt")
	    table = rank_by_goal_diff(table)

		row_1 = "    1. Aston_Villa     38    12  14  12    46  -  47    50"
		row_8 = "    8. Middlesbrough   38    12   9  17    35  -  47    45"
		row_17 = "   17. Leicester       38     5  13  20    30  -  64    28"

   		assert_equal(table.split("\n")[1], row_1)
   		assert_equal(table.split("\n")[8], row_8)
   		assert_equal(table.split("\n")[17], row_17)
   end

	def test_least_temp_diff
		table = read_table("weather.txt")
		least_diff_line = "  14  61    59    60       5  55.9       0.00 RF      060  6.7 080   9 10.0  93 87 1008.6\n"

		assert_equal(least_temp_diff(table), least_diff_line)
	end

	def test_rank_by_temp_diff
		table = read_table("weather.txt")
	    table = rank_by_temp_diff(table)

		row_4 = "  24  90    77    84          67.5       0.00 H       350  8.5 010  14  6.9  74 48 1018.2"
		row_13 = "  10  84    64    74          57.5       0.00 F       210  6.6 050   9  3.4  84 40 1019.0"
		row_24 = "  21  86    59    73          57.7       0.00 F       240  6.1 250  12  1.0  87 35 1030.7"

   		assert_equal(table.split("\n")[4], row_4)
   		assert_equal(table.split("\n")[13], row_13)
   		assert_equal(table.split("\n")[24], row_24)
	end
end


class Tests_Upg2 < Test::Unit::TestCase
	def test_stream_parsing
		events = []
		lst = MyListener.new(events)
		src = File.new "events.html"
		REXML::Document.parse_stream(src,lst) # namespace::class.method(file, listener)

		assert_equal(events.length, 8)

		assert_equal(events[0].data['summary'], "The Dark Carnival - 101.9FM")
		assert_equal(events[1].data['summary'], "Sinister Sundays")

		assert_not_equal(events[0].data['summary'], "Sinister Sundays")
		assert_equal(events[0].data['street-address'], nil)

		assert_equal(events[4].data['dtstart'], "2008-01-18 10:00pm EST")
		assert_equal(events[5].data['region'], "Ontario")

		assert_equal(events[7].data['org fn'], "The Bohemian")
		assert_equal(events[7].data['locality'], "Belleville")
		assert_equal(events[7].data['description'], "Gothic, Industrial, Dark Alternative w/ DJ LunaSlave")
	end

	def test_dom_parsing
		events = []
		file = File.new( "events.html" )
		doc = REXML::Document.new file
		dom_parsing(events, doc)

		assert_equal(events.length, 8)

		assert_equal(events[0].data['summary'], "The Dark Carnival - 101.9FM")
		assert_equal(events[1].data['summary'], "Sinister Sundays")

		assert_not_equal(events[0].data['summary'], "Sinister Sundays")
		assert_equal(events[0].data['street-address'], nil)

		assert_equal(events[4].data['dtstart'], "2008-01-18 10:00pm EST")
		assert_equal(events[5].data['region'], "Ontario")

		assert_equal(events[7].data['org fn'], "The Bohemian")
		assert_equal(events[7].data['locality'], "Belleville")
		assert_equal(events[7].data['description'], "Gothic, Industrial, Dark Alternative w/ DJ LunaSlave")

	end
end