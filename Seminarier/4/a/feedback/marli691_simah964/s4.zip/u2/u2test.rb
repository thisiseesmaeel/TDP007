require "./constraint-parser.rb"
require "test/unit"

class TestU2 < Test::Unit::TestCase
  def test_assgin_100
    cp = ConstraintParser.new
    c, f = cp.parse "9*c=5*(f-32)"
    f.user_assign 100
    assert_equal(c.value, 37)
    f.forget_value "user"
    c.user_assign 100
    assert_equal(f.value, 212)
  end

  def test_assign_0
    cp = ConstraintParser.new
    c, f = cp.parse "9*c=5*(f-32)"
    c.user_assign 0
    assert_equal(f.value, 32)
    c.forget_value "user"
    f.user_assign 0
    assert_equal(c.value, -18)
  end

  def test_two_equal
    cp = ConstraintParser.new
    c, f = cp.parse "1*c=1*f"
    c.user_assign 2
    assert_equal(f.value, 2)
    c.forget_value "user"
    f.user_assign 10
    assert_equal(c.value, 10)
  end

  def test_to_the_power_of
    cp = ConstraintParser.new
    c, f = cp.parse "c*c=(f+0)"
    c.user_assign 3
    assert_equal(f.value, 9)

    f.forget_value "user"
    c.user_assign 10
    assert_equal(f.value, 100)
  end

  def test_three_connectors
    cp = ConstraintParser.new
    e, m, c = cp.parse "e=m*c*c"
    c.user_assign 3
    m.user_assign 10
    assert_equal(e.value, 90)
  end
end
