# Seminarie 4:
## Uppgift 1:

När vi började med uppgiften tog det ganska lång tid att kolla igenom och förstå hela koden.  Det var även klurigt att veta vad man skulle testa. Vi tror att vi testat allt som behövdes. Det felet i koden som vi hittade var att det endast fungerar om man skulle ge ett nytt värde till a eller b med user assign. Det vi då behövde ändra på var i funktionen new_value. Vi satte in två elsif satser för att kunna ändra på a om a inte har ett värde och b har värde ett värde och out är det man kör assign på samt en sats för om b inte har ett värde, a har ett värde och c skall ändras med assign. 

I koden finns det en klass som heter ContradictionException som ärver från Exception. I vår lösning av denna uppgiften har vi inte använt den klassen. Vi förstod inte riktigt om den skulle användas och i så fall hur den skulle implementeras. Vi tror vi har lyckats lösa uppgiften ändå så vi skippade att använda oss av den.

Om man kollar igenom filen kan man se att vi även har klasserna Divider och Subtracter. De användes inte för denna uppgiften utan lades till när vi jobbade med uppgift 2.

När vi skulle göra funktionen “celsius2fahrenheit” använde vi oss av klasserna Multiplier och Adder. Det är två värden i uträkningen som inte behövde ändras och av den anledningen skapade vi dem som ConstantConnector objekt. Connector “a” är värdet i celsius och fahrenheit är då Connector “e”. Connector “c” är det som håller sidorna av ekvationen tillsammans. 

Det var en intressant uppgift och teknik att sätta sig in i även om den var lite klurig. Det som var svårast med uppgiften var att komma igång med att skriva testerna eftersom det var så mycket kod som man behövde förstå. När man skulle göra funktionen för att kunna räkna ut fahrenheit och celsius var det väldigt enkelt, trots det var det svårt att exakt förstå hur den fungerar från en programmerings-synvinkel. Det var till exempel inte helt uppenbart hur programmet fungerade under huven och uppdaterade alla värden när user_assign kördes. Att det var så enkelt visar på att det kan vara en väldigt användbar teknik.    

## Uppgift 2:

När vi började med uppgift 2 så ändrade vi först syntax-felen i replace_conn funktionen. Sedan skapades get_connector som egentligen är lite fel namngiven då den enbart extraherar en Connector när en Constraint skickas in som parameter.

Eftersom uppgift 2 använde delar av uppgift 1 så var det viktigt att den var korrekt implementerad innan vi började felsöka. För att division och subtraktion skulle fungera korrekt försökte vi först lösa det med enbart Adder och Multiplier, dock stötte vi på problem när vi returnerade conn.out i get_connector funktionen. Problemet var att vi inte visste när vi skulle return out eller b eftersom ArithmeticConstraint klassen inte hade något sätt att komma ihåg om den var t.ex. Addition eller subtraktion.
Först tänkte vi att det skulle gå att multiplicera med inversen av talet innan den behandlades av funktionen men det skulle enbart funka på konstanter och förstöra poängen med programmet.
Vi löste problemet genom att skapa klasserna Divider och Subtractor i u1.rb. Det fungerade direkt och var en snabb lösning, dock hade det varit snyggt att enbart använda Adder och Multiplier.  
  
När vi gjorde testerna upptäckte vi att programmet även kunde hantera fler än två variabler, att multiplicera en variabel med sig själv fungerade också utan att vi behövde skriva någon extra kod.

Vi tyckte att uppgiften var relativt svår att lösa eftersom det inte fanns en lika tydlig ordning som funktionerna kördes i som i tidigare kurser när allt är block som skickas som parametrar. Att dessa block körs av ett program som vi själva inte har skrivit gjorde självklart att det tog längre tid att sätta sig in i uppgiften.
Det hjälpte att vi fick grundstrukturen för hur lösningen skulle se ut trots att den innehöll diverse fel.

En begränsning med den nuvarande implementationen är att det t.ex. inte går att skriva “f=c” enbart då det inte innehåller någon constraint i funktionen replace_conn. Om man däremot skriver “(f+1)=(c+0)” så fungerar programmet. 

## Reflektion:
Det känns som att vi har blivit mer bekanta med parsers och funktionsblock i denna veckas uppgifter eftersom det krävdes en ganska djup förståelse för hur programmet fungerade innan uppgifterna kunde lösas.
Det var också en några delar av uppgiften som var generellt utmanande från ett problemlösar-perspektiv. Att göra implementationen för hur ekvationer skulle gå att vända på och klara av alla kombinationer av saknade variabler var en av dessa delar.
Det känns som att vi blivit mer förberedda för den kommande kursen när vi ska göra eget programmeringsspråk efter de senaste 2 veckornas uppgifter.
